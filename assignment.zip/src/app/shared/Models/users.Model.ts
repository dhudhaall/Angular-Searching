export interface Users{
    id: string,
    type: string,
    login:string,
    avatar_url:string
}