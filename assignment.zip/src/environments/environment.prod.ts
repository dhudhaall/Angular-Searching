export const environment = {
  production: true,
  apiEndPoint: 'https://api.github.com'
};
